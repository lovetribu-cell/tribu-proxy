
export const config = { runtime: "edge" };

export default async function handler(req) {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: corsHeaders() });
  }

  try {
    const body = await req.json();
    const imageBase64 = body?.imageBase64;
    const minConfidence = typeof body?.minConfidence === "number" ? body.minConfidence : 0.75;
    const model = body?.model || "gpt-4o-mini";

    if (!imageBase64) {
      return new Response(JSON.stringify({ error: "Missing imageBase64 in request body" }), { status: 400, headers: corsHeaders() });
    }

    // Prompt instructing the model to return strict JSON
    const prompt = `Tu es un expert en reconnaissance d'animaux.
Analyse l'image fournie (format base64) et retourne uniquement un objet JSON strict :
{
  "animal": "chien|chat|inconnu",
  "breed": "string (vide si confiance < minConfidence)",
  "confidence": 0.0,
  "candidates": [{ "label": "string", "score": 0.0 }]
}
Règles :
- Liste jusqu'à 3 candidats avec score 0..1.
- Les labels doivent être précis (ex: Labrador Retriever, Maine Coon).
- Ne retourne rien hors JSON.`;

    const openaiRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // IMPORTANT: OPENAI_API_KEY must be set as an environment variable in Vercel/Cloudflare.
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: prompt },
          { role: "user", content: [
            { type: "input_text", text: "Analyse cette image (base64) :" },
            { type: "input_image", image_url: `data:image/jpeg;base64,${imageBase64}` }
          ] }
        ],
        response_format: { type: "json_object" },
        max_tokens: 1024
      })
    });

    if (!openaiRes.ok) {
      const text = await openaiRes.text();
      console.error("OpenAI error:", openaiRes.status, text);
      return new Response(JSON.stringify({ error: "OpenAI API error", details: text }), { status: 502, headers: corsHeaders() });
    }

    const openaiJson = await openaiRes.json();
    const rawContent = openaiJson?.choices?.[0]?.message?.content;
    if (!rawContent) {
      console.error("No content from OpenAI:", JSON.stringify(openaiJson));
      return new Response(JSON.stringify({ error: "Bad OpenAI response" }), { status: 502, headers: corsHeaders() });
    }

    // rawContent should already be a JSON object (response_format=json_object). If it's a string, try parse.
    let result = rawContent;
    if (typeof rawContent === "string") {
      try { result = JSON.parse(rawContent); } catch (e) { 
        console.error("JSON parse error:", e, rawContent); 
        return new Response(JSON.stringify({ error: "Invalid JSON from model" }), { status: 502, headers: corsHeaders() });
      }
    }

    // Normalisation FR
    const animalLower = String(result.animal || "").toLowerCase();
    if (animalLower.includes("dog") || animalLower.includes("chien")) result.animal = "chien";
    else if (animalLower.includes("cat") || animalLower.includes("chat")) result.animal = "chat";
    else result.animal = "inconnu";

    // If confidence lower than threshold, hide breed
    if (typeof result.confidence === "number" && result.confidence < minConfidence) {
      result.breed = "";
    }

    // Ensure the shape matches expectations
    const output = {
      animal: result.animal || "inconnu",
      breed: result.breed || "",
      confidence: typeof result.confidence === "number" ? result.confidence : 0,
      candidates: Array.isArray(result.candidates) ? result.candidates.slice(0,3).map(c=>({ label: c.label, score: Number(c.score) })) : []
    };

    return new Response(JSON.stringify(output), { status: 200, headers: corsHeaders() });
  } catch (err) {
    console.error("Handler error:", err);
    return new Response(JSON.stringify({ error: err.message || String(err) }), { status: 500, headers: corsHeaders() });
  }
}

function corsHeaders() {
  return {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
}


Tribu Proxy for OpenAI Vision (Vercel Edge Function)
---------------------------------------------------

Fichiers:
/api/vision-proxy.js  - endpoint edge (POST) expect JSON { imageBase64, minConfidence }

Installation rapide (Vercel - méthode Upload):
1) Sur Vercel: New Project -> Import -> Upload (ou Import Manually / Other)
2) Uploade ce dossier (tribu-proxy.zip)
3) Dans Settings > Environment Variables:
   - OPENAI_API_KEY = sk-... (colle TA clé ici, NE LA PARTAGE PAS)
4) Deploy

Test rapide (curl):
curl -X POST "https://<ton-deploiement>.vercel.app/api/vision-proxy" -H "Content-Type: application/json" -d '{
  "imageBase64":"<BASE64_IMAGE_WITHOUT_PREFIX>",
  "minConfidence":0.75
}'

Response example:
{
  "animal": "chien",
  "breed": "Labrador Retriever",
  "confidence": 0.92,
  "candidates":[{"label":"Labrador Retriever","score":0.92},{"label":"Golden Retriever","score":0.05}]
}

IMPORTANT:
- NE PAS exposer OPENAI_API_KEY dans le front-end.
- Après avoir testé, RÉVOQUE la clé que tu as accidentellement partagée publiquement et crée-en une nouvelle via https://platform.openai.com/account/api-keys
